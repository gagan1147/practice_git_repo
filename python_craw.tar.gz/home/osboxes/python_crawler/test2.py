import requests
from bs4 import BeautifulSoup
import os
import time
count = 0
base_url = 'https://www.zalando.fr'
base_dir = os.getcwd()

header = {

    'if-none-match': 'W/"340-Q8hpQxylzf/opZmh35f98skFVWc"',
    'x-xsrf-token': 'AAAAAFC_g3k0kI-fo_KJZ9UrFBdKHZTaGteaQguJmt6p5A-FYxLoIW73ajdX2VCrk2yim9-UhLaNhffi72gyDR2THhCZMrH-3AHgDGm9XSXs4t252wmUF8QOeJGf6sNUCbl46aBJfNhT8UgNx2jVug==',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.80 Safari/537.36',
    'accept': '/',
    'authority': 'www.zalando.fr',
    'accept-encoding': 'gzip, deflate, br',
}


def imagedown(url, folder):
    file_dir = os.path.join(os.getcwd(), folder)
    #print file_dir
    try:
        os.mkdir(file_dir)
    except:
        pass
    os.chdir(file_dir)
    try:
        r = requests.get(url,headers = header)
        soup = BeautifulSoup(r.text, 'html.parser')
        divs = soup.find('div',{'class':'qMZa55 WzZ4iu _01vVuu _6GQ88b WdG8Bv'})
        images = divs.find_all('img')
        #print len(images)

        for image in images:
            name = image['alt']
            link = image['src']
            #name_li = image['srcset']
            #print name_li
            with open(name.replace(' ', '-').replace('/', '') + '.jpg', 'wb') as f:
                im = requests.get(link)
                f.write(im.content)
                print('Writing: ', name)
    except:
        pass
    os.chdir(base_dir)

for i in range(1,100):
    url = 'https://www.zalando.fr/t-shirts-tops-femme/?p='+str(i)
    print url
    r = requests.get(url,headers = header)
    c = r.content
    soup = BeautifulSoup(c, 'html.parser')
    images = soup.find_all('a',{'class':'g88eG_ oHRBzn LyRfpJ _LM JT3_zV g88eG_'})
    #count = 0
    for img in images:
        imagedown(base_url+img['href'],"img"+str(count))
        #print base_url+img['href'],'\n'
        time.sleep(5)
        count = count + 1
