required

python==2.7.17
bs4==4.9.3
request==2.25.1

How to run

python test2.py
